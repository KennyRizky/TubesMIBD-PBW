<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="view/css/style.css">
</head>
<body>
	<div id="header">
		<a id="logo" href="index">Study Hub</a>
	</div>


	<?php echo $content; ?>

</body>
</html>